package com.example.scrolling;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class adding_project extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.project_create);
    }

    public void Fuck_go_back(View v)
    {
        Intent intent = new Intent(adding_project.this,pre_adding_project.class);
        startActivity(intent);
    }
}