package com.example.scrolling;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class pre_adding_project extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pre_adding_project);
    }

    public void Go_back_to_scroll(View v){
        Intent intent = new Intent(pre_adding_project.this,MainActivity.class);
        startActivity(intent);
    }

    public void Moreinfo(View v){
        Intent intent = new Intent(pre_adding_project.this,More_about.class);
        startActivity(intent);
    }

    public void Go_to_create(View v)
    {
        Intent intent = new Intent(pre_adding_project.this,adding_project.class);
        startActivity(intent);
    }
}