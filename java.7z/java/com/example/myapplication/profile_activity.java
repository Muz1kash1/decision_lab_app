package com.example.myapplication;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.myapplication.fargment_letter;
import com.example.myapplication.statistic;
import com.example.myapplication.star;

public class profile_activity extends AppCompatActivity {
    private ImageButton account_button, news_button, quest_buttton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_activity);
        addListenerOnButton();

    }
    public void Change (View view){
        Fragment fragment = null;

        switch (view.getId()){
            case R.id.letter:
                fragment = new fargment_letter();
                break;
            case R.id.star:
                fragment = new star();
                break;
            case R.id.statistic:
                fragment = new statistic();
                break;

        }

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.fragment_for_profile, fragment);
        ft.commit();

    }
    public void  addListenerOnButton(){
        account_button = (ImageButton)findViewById(R.id.account_button);
        news_button =(ImageButton)findViewById(R.id.news_button);
        quest_buttton =(ImageButton)findViewById(R.id.quest_button);
        account_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("..profile_activity");
                startActivity(intent);
            }
        });
        quest_buttton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextPAge_quest = new Intent(".quest_page");
                startActivity(nextPAge_quest);
            }
        });
        news_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextPAge = new Intent(".MainActivity");
                startActivity(nextPAge);
            }
        });


    }



}