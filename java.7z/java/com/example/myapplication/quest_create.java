package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class quest_create extends AppCompatActivity {
    private Button account_button, news_button, quest_buttton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quest_create);
    }

    public void  addListenerOnButton(){
        account_button = (Button)findViewById(R.id.account_button);
        news_button =(Button)findViewById(R.id.news_button);
        quest_buttton =(Button)findViewById(R.id.quest_button);
        account_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("..profile_activity");
                startActivity(intent);
            }
        });
        quest_buttton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextPAge_quest = new Intent(".quest_page");
                startActivity(nextPAge_quest);
            }
        });
        news_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextPAge = new Intent(".MainActivity");
                startActivity(nextPAge);
            }
        });


    }
}
