package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class quest_page extends AppCompatActivity {
    private ImageButton account_button, news_button, quest_buttton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quest_page);
        addListenerOnButton();
    }

    public void  addListenerOnButton(){
        account_button = (ImageButton)findViewById(R.id.account_button);
        news_button =(ImageButton)findViewById(R.id.news_button);
        quest_buttton =(ImageButton)findViewById(R.id.quest_button);
        account_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("..profile_activity");
                startActivity(intent);
            }
        });
        quest_buttton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextPAge_quest = new Intent(".quest_page");
                startActivity(nextPAge_quest);
            }
        });
        news_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nextPAge = new Intent(".MainActivity");
                startActivity(nextPAge);
            }
        });


    }
}
